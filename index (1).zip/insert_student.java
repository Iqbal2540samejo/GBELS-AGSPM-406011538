ContentValues values = new ContentValues();
values.put("name", "John Doe");
values.put("class", "10th Grade");
values.put("roll_no", 23);

SQLiteDatabase db = this.getWritableDatabase();
db.insert("students", null, values);
db.close();