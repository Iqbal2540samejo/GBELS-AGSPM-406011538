public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "school.db";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students (ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, class TEXT, roll_no INTEGER)");
        db.execSQL("CREATE TABLE teachers (ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, subject TEXT)");
        db.execSQL("CREATE TABLE courses (ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, credits INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS students");
        db.execSQL("DROP TABLE IF EXISTS teachers");
        db.execSQL("DROP TABLE IF EXISTS courses");
        onCreate(db);
    }
}