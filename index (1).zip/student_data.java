DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("Students");

HashMap<String, Object> studentData = new HashMap<>();
studentData.put("name", "John Doe");
studentData.put("class", "10th Grade");
studentData.put("roll_no", 23);

myRef.child("student_id_1").setValue(studentData);